import type { Candle } from '../types';
export declare function computeMA(data: Candle[], period: number): (number | null)[];
//# sourceMappingURL=indicators.d.ts.map