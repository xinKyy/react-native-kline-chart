import type { SharedValue } from 'react-native-reanimated';
import type { Candle } from '../types';
type GestureParams = {
    scrollOffset: SharedValue<number>;
    candleWidth: SharedValue<number>;
    crosshairX: SharedValue<number>;
    crosshairVisible: SharedValue<boolean>;
    dataLength: number;
    chartWidth: number;
    candleSpacing: number;
    minCandleWidth: number;
    maxCandleWidth: number;
    rightPaddingCandles: number;
    onCrosshairChange?: (candle: Candle | null) => void;
};
export declare function useChartGestures(params: GestureParams): import("react-native-gesture-handler/lib/typescript/handlers/gestures/gestureComposition").SimultaneousGesture;
export {};
//# sourceMappingURL=useChartGestures.d.ts.map