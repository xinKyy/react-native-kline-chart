import type { Candle } from '../types';
/**
 * Flat data layout per candle (stride = 5):
 *   [time, open, high, low, close, time, open, high, low, close, ...]
 *
 * MA arrays use NaN instead of null for missing values.
 */
export declare function useChartData(data: Candle[], maPeriods: number[]): {
    dataShared: import("react-native-reanimated").SharedValue<number[]>;
    maShared: import("react-native-reanimated").SharedValue<number[][]>;
};
//# sourceMappingURL=useChartData.d.ts.map