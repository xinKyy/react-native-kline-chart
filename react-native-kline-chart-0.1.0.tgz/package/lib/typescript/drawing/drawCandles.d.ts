import type { SkCanvas, SkPaint } from '@shopify/react-native-skia';
import type { Candle } from '../types';
export declare function drawCandles(canvas: SkCanvas, data: Candle[], _startIndex: number, candleWidth: number, candleSpacing: number, chartHeight: number, minPrice: number, priceRange: number, bullPaint: SkPaint, bearPaint: SkPaint, wickBullPaint: SkPaint, wickBearPaint: SkPaint): void;
export declare function priceToY(price: number, chartHeight: number, minPrice: number, priceRange: number): number;
//# sourceMappingURL=drawCandles.d.ts.map