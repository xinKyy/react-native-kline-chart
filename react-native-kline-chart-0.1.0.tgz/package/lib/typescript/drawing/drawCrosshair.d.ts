import type { SkCanvas, SkPaint, SkFont } from '@shopify/react-native-skia';
import type { Candle } from '../types';
export declare function drawCrosshair(canvas: SkCanvas, candle: Candle, x: number, chartWidth: number, chartHeight: number, minPrice: number, priceRange: number, linePaint: SkPaint, bgPaint: SkPaint, labelPaint: SkPaint, font: SkFont | null, yAxisWidth: number): void;
//# sourceMappingURL=drawCrosshair.d.ts.map