import type { SkCanvas, SkPaint } from '@shopify/react-native-skia';
export declare function drawMALine(canvas: SkCanvas, maValues: (number | null)[], startIndex: number, visibleCount: number, candleWidth: number, candleSpacing: number, chartHeight: number, minPrice: number, priceRange: number, paint: SkPaint): void;
//# sourceMappingURL=drawMA.d.ts.map