import type { SkCanvas, SkPaint, SkFont } from '@shopify/react-native-skia';
export declare function drawGrid(canvas: SkCanvas, chartWidth: number, chartHeight: number, minPrice: number, maxPrice: number, gridPaint: SkPaint, textPaint: SkPaint, font: SkFont | null, yAxisWidth: number): void;
//# sourceMappingURL=drawGrid.d.ts.map